require('./config');
const { WA_DEFAULT_EPHEMERAL } = require('@whiskeysockets/baileys').default

function GroupParticipants(Zion, { id, participants, action, author }) {
    Zion.groupMetadata(id)
        .then(gcdata => {
            const subject = gcdata.subject

            for (const jid of participants) {
                let check = author && author !== jid && author.length > 1
                let tag = check ? [author, jid] : [jid]

                switch (action) {
                    case "add":
                        Zion.sendMessage(id, {image: {url: `https://api.siputzx.my.id/api/canvas/welcomev4?avatar=https://files.catbox.moe/nwvkbt.png&background=${thumbnail}&description=@${jid.split("@")[0]}` }, caption: `𝚈𝚘 @${jid.split("@")[0]} ☢︎︎\n\n𝚆𝚎𝚕𝚌𝚘𝚖𝚎 𝚑𝚎𝚛𝚎 *${subject}*!\n𝙼𝚊𝚔𝚎 𝚜𝚞𝚛𝚎 𝚢𝚘𝚞 𝚐𝚎𝚝 𝚝𝚑𝚎 𝚛𝚞𝚕𝚎𝚜 𝚜𝚔𝚒𝚒 𝚑𝚊𝚟𝚎 𝚊 𝚗𝚒𝚌𝚎 𝚝𝚒𝚖𝚎 𝚑𝚎𝚛𝚎 ☢︎︎`,
                                contextInfo: { mentionedJid: [jid] }
                            },
                            { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                        )
                        break

                    case "remove":
                        Zion.sendMessage(id, {image: {url: `https://api.siputzx.my.id/api/canvas/goodbyev4?avatar=https://files.catbox.moe/nwvkbt.png&background=${thumbnail}&description=@${jid.split("@")[0]}` }, caption: `𝙱𝚢𝚎 𝙰𝚖𝚒𝚐𝚘 @${jid.split("@")[0]} 𝚂𝚝𝚊𝚢 𝚌𝚘𝚘𝚕 
> spectre`,
                                contextInfo: { mentionedJid: [jid] }
                            },
                            { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                        )
                        break

                    case "promote":
                        if (author) {
                            Zion.sendMessage(
                                id,
                                {
                                    text: `𝚈𝚘𝚘𝚘...*@${author.split("@")[0]} 𝙼𝚊𝚍𝚎 @${jid.split("@")[0]} 𝙾𝚗𝚎 𝚘𝚏 𝚝𝚑𝚎 𝚝𝚘𝚙 𝚍𝚊𝚠𝚐𝚜 𝚒𝚗 𝚝𝚋𝚒𝚜 𝚛𝚎𝚊𝚕𝚖 👑`,
                                    contextInfo: { mentionedJid: [...tag] }
                                },
                                { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                            )
                        }
                        break

                    case "demote":
                        if (author) {
                            Zion.sendMessage(
                                id,
                                {
                                    text: `𝚂𝚑𝚒𝚒...*@${author.split("@")[0]} 𝚁𝚎𝚖𝚘𝚟𝚎𝚍 @${jid.split("@")[0]} 𝙵𝚛𝚘𝚖 𝚝𝚑𝚎 𝚝𝚘𝚙 𝚍𝚊𝚠𝚐𝚜* 🥲`,
                                    contextInfo: { mentionedJid: [...tag] }
                                },
                                { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                            )
                        }
                        break

                    default:
                        console.log(`⚠️ Unknown Action: ${action} for ${jid} in grup ${subject}`)
                }
            }
        })
        .catch(err => {
            console.error(err)
        })
}

module.exports = GroupParticipants