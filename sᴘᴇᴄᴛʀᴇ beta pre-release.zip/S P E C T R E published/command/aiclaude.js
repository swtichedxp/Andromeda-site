const fetch = require('node-fetch');

const handler = async (m, { text }) => {
    if (!text) {
        return m.reply('Please enter text for the AI!');
    }

    try {
        const response = await fetch(`https://api.ryzendesu.vip/api/ai/claude?text=${encodeURIComponent(text)}`);
        const result = await response.json();

        if (!result || !result.response) {
            throw new Error('Shii.. Failed to get a response from the API.');
        }

        m.reply(result.response); 
    } catch (error) {
        console.error(error);
        m.reply('looks like an error occurred while answering skiii. Try again 🥲.');
    }
};

handler.help = ['claude <text>'];
handler.tags = ['ai'];
handler.command = ['aiclaude'];

module.exports = handler;