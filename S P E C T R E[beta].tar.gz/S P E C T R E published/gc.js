require('./config');
const { WA_DEFAULT_EPHEMERAL } = require('@whiskeysockets/baileys').default

function GroupParticipants(Zion, { id, participants, action, author }) {
    Zion.groupMetadata(id)
        .then(gcdata => {
            const subject = gcdata.subject

            for (const jid of participants) {
                let check = author && author !== jid && author.length > 1
                let tag = check ? [author, jid] : [jid]

                switch (action) {
                    case "add":
                        Zion.sendMessage(id, {image: {url: `https://api.siputzx.my.id/api/canvas/welcomev4?avatar=https://files.catbox.moe/nwvkbt.png&background=${thumbnail}&description=@${jid.split("@")[0]}` }, caption: `Heyo @${jid.split("@")[0]} 👋\n\nWelcome to *${subject}*!\nMase sure you check the group rules skii 😊✨`,
                                contextInfo: { mentionedJid: [jid] }
                            },
                            { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                        )
                        break

                    case "remove":
                        Zion.sendMessage(id, {image: {url: `https://api.siputzx.my.id/api/canvas/goodbyev4?avatar=https://files.catbox.moe/nwvkbt.png&background=${thumbnail}&description=@${jid.split("@")[0]}` }, caption: `Bye Amigo @${jid.split("@")[0]} 👋\nKeep Clam, Stay Cool! 🚀
> spectre/zed`,
                                contextInfo: { mentionedJid: [jid] }
                            },
                            { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                        )
                        break

                    case "promote":
                        if (author) {
                            Zion.sendMessage(
                                id,
                                {
                                    text: `Yo Fellas*@${author.split("@")[0]} Pomoted @${jid.split("@")[0]} To the Admin hood* 👑`,
                                    contextInfo: { mentionedJid: [...tag] }
                                },
                                { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                            )
                        }
                        break

                    case "demote":
                        if (author) {
                            Zion.sendMessage(
                                id,
                                {
                                    text: `Damn Fellas*@${author.split("@")[0]} Demoted @${jid.split("@")[0]} From Admin hood* 🚫shii`,
                                    contextInfo: { mentionedJid: [...tag] }
                                },
                                { ephemeralExpiration: WA_DEFAULT_EPHEMERAL }
                            )
                        }
                        break

                    default:
                        console.log(`⚠️ Unknown Action: ${action} for ${jid} in grup ${subject}`)
                }
            }
        })
        .catch(err => {
            console.error(err)
        })
}

module.exports = GroupParticipants