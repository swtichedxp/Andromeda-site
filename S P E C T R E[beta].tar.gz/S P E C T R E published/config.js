require("./Zion")
const fs = require('fs')
const { version } = require("./package.json")
//~~~~~~~~~SETTING BOT~~~~~~~~~~//

// Bebas Ubah
global.owner = "255673788367"
global.nobot = "255673788367"
global.namaowner = "Spectre"
global.namaBot = "Spectre"
global.title = "Spectre"

// Jangan Di ubah
global.creator = `${owner}@s.whatsapp.net` 
global.foother = `© ${namaBot}`
global.versi = version
global.nama = namaBot 
global.namach = nama 
global.namafile = foother 
global.author = namaowner

// Bebas Ubah
// True = on || False = Off 
global.autoread = false
global.autotyping = false
global.Antilinkgc = false
global.Antilinkch = false
global.antispam = false
global.onlygc = false
global.autobio = false

//

// ===={ Set Link }
global.ch = 'https://whatsapp.com/channel/0029VbBWprT3WHTgc1iURQ2U'
global.idch = '120363421464922971@newsletter'
global.linkgc = 'https://chat.whatsapp.com/E1jBqMEJcp3LlYtz8QYGkD?mode=ems_copy_t'
global.yt = 'switchedxp'
global.nekorin = "https://api.nekorinn.my.id"
global.idgc = "120363403943482469@g.us"
// set prefix
global.setprefix = ".", "/", "#"

// User Sosmed
global.tt = "@zedside"
global.yt = "@switchedxp"
global.portf = ""

// Setting Api cVPS
global.doToken = "APIKEY"
global.linodeToken = "APIKEY"

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://"
global.apikey = "ptla" //ptla
global.capikey = "ptlc" //ptlc

// [ THEME URL & URL ] ========//
global.thumbnail = 'https://ik.imagekit.io/apexcloud/spectre.jpg'

// Settings reply ~~~~~~~~~//
global.mess = {
    owner: "Sorry Owner Only",
    prem: "Sorry Premium Only",
    group: "For Group Chats Only",
    admin: "Admin Only",
    botadmin: "Bot Must Be An Admin",
    private: "Private Chat Only ",
    done: "Success ✅ ✨"
}

global.packname = nama
global.author = namaBot

//
global.gamewaktu = 60 // Game waktu
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar2 = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};

//~~~~~~~~~~~ DIEMIN ~~~~~~~~~~//

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
