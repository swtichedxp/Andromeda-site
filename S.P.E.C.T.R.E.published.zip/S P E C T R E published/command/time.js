const fetch = require('node-fetch');

const handler = async (m, { text, client }) => {
    if (!text) {
        return client.sendMessage(
            m.chat,
            { text: 'Please enter a city name or timezone to check the local time!🌍🌏🌎' },
            { quoted: m }
        );
    }

    try {
        const apiKey = '7VOSSFOJP5RX'; // API key Anda
        const response = await fetch(
            `https://api.timezonedb.com/v2.1/get-time-zone?key=${apiKey}&format=json&by=zone&zone=${text}`
        );

        if (!response.ok) throw new Error('Damn Failed To Retrive Time Data.');

        const result = await response.json();

        if (result.status !== 'OK') {
            return client.sendMessage(
                m.chat,
                { text: `The time zone for "${text}" was not found. Please try again!
` },
                { quoted: m }
            );
        }

        const { formatted, zoneName } = result;
        await client.sendMessage(
            m.chat,
            {
                text: `🕒 *Local Time*\n\n📍 TimeZone: ${zoneName}\n⏰ Time: ${formatted}`,
            },
            { quoted: m }
        );
    } catch (error) {
        console.error(error);
        client.sendMessage(
            m.chat,
            { text: 'Dang.. An Error Occured While Retrieving Local Time Try Again Later!' },
            { quoted: m }
        );
    }
};

handler.help = ['time <time zone>'];
handler.tags = ['utility'];
handler.command = ['time', 'time'];

module.exports = handler;